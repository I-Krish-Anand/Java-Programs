import java.util.Scanner;

public class Main {
    static int search(char[]arr,char ele,int i,int j)
    {
        if(j<i)
            return -1;
        if(arr[i]==ele)
            return i;
        if(arr[j]==ele)
            return j;

        return search(arr,ele,i+1,j-1);
    }
    public static void main(String[] args)
    {

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter string");
        String a=sc.next();
        System.out.println("Enter element to search");
        char ele=sc.next().charAt(0);
        int b=search(a.toCharArray(),ele,0,a.length()-1);
        if(b==-1)
            System.out.println("Element not found");
        else
            System.out.println("Element found at: "+b);
    }
}