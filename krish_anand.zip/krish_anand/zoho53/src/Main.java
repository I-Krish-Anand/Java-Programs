import java.util.*;
public class Main {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String a=sc.next();
        int num=0,index=-1;
        for(int i=0;i<a.length();i++)
        {
            if(a.charAt(i)>=48 && a.charAt(i)<=57)
            {
                num*=10;
                num+=(a.charAt(i)-48);
            }
            else
            {
                if(i>0) {
                    for (int k = 0; k < num; k++)
                        System.out.print(a.charAt(index));
                    num = 0;
                }
                index=i;
            }
        }
        for (int k = 0; k < num; k++)
            System.out.print(a.charAt(index));
    }
}