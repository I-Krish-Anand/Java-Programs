import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        char ch=sc.next().charAt(0);
        if((ch>=65 && ch<97) || (ch>=97 &&ch<123))
            System.out.println(ch+" is a Alphabet");
        else
                System.out.println(ch+" is not a Alphabet");
    }
}