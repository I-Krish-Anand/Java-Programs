import java.util.*;
public class Main {
    static boolean checkEven(int i)
    {
        return i%2==0;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        if(checkEven(n))
            System.out.println(n+" is even");
        else
            System.out.println(n+" is odd");
    }
}