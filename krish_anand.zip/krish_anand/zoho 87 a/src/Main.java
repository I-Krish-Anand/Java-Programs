import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        char[] ch={'w','e','l','c','o','m','e'};
        String a=new String(ch);
        System.out.println(a);
    }
}