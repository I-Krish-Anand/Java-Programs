public class Main
{
    static void matrixRec(int i,int j,int[][]a,boolean[][]map,int[][]res)
    {
        if(i==a.length || j==a[0].length||i==-1||j==-1)
            return;

        if(map[i][j])
            return;

        if(i<=j)
            res[i][j]=a[i][j];

        map[i][j]=true;

        matrixRec(i,j+1,a,map,res);
        matrixRec(i+1,j,a,map,res);
        matrixRec(i,j-1,a,map,res);
        matrixRec(i-1,j,a,map,res);
    }
    public static void main(String[] args) {

        int a[][] = {{19, 8, 17},
                {6, 14, 16},
                {4, 15, 17}};
        if(a.length != a[0].length ){
            System.out.println("Upper triangular matrix can't be formed");
        }
        else {
            boolean[][] map=new boolean[a.length][a[0].length];
            int[][] res=new int[a.length][a[0].length];
            matrixRec(0,0,a,map,res);
            for(int i = 0; i < a.length; i++)
            {
                for(int j = 0; j < a[0].length; j++)
                    System.out.print(res[i][j]+" ");
                System.out.println();
            }
        }
    }
}