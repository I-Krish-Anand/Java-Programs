import java.util.Scanner;

public class Main {
    static void matrixRec(int i,int j,int[][]a,boolean[][]map,int[][]res)
    {
        if(i==a.length || j==a[0].length||i==-1||j==-1)
            return;

        if(map[i][j])
            return;

        res[i][j]=a[j][i];
        map[i][j]=true;

        matrixRec(i,j+1,a,map,res);
        matrixRec(i+1,j,a,map,res);
        matrixRec(i,j-1,a,map,res);
        matrixRec(i-1,j,a,map,res);
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int row=sc.nextInt();
        int col= sc.nextInt();
        int[][]a=new int[row][col];
        for (int i=0;i< a.length;i++)
        {
            for (int j=0;j<a[0].length;j++)
                a[i][j]=sc.nextInt();
        }
        //Print resultant matrix
        boolean map[][]=new boolean[a.length][a[0].length];
        int res[][]=new int[a.length][a[0].length];
        matrixRec(0,0,a,map,res);
        for(int i=0;i<a.length;i++)
        {
            for(int j=0;j<a.length;j++)
                System.out.print(res[i][j]+" ");
            System.out.println();
        }
    }
}