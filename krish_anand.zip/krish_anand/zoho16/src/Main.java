import java.util.Scanner;

public class Main
{
    static int evalPoly(int[] arr, int x)
    {
        int res=arr[0];
        for(int i=1;i<arr.length;i++)
           res=res*x+arr[i];

        return res;

    }
    public static void main (String[] args)
    {
        // 2x3 - 6x2 + 2x - 1 for x = 3  ((2x-6)x+ +2)x -1
       // int[] arr = {2, -6, 2, -1};
        Scanner sc=new Scanner(System.in);
        System.out.println("Highest degree of polynomial:");
        int n=sc.nextInt();
        int[]arr=new int[n+1];
        for(int i=0;i<n+1;i++)
            arr[i]= sc.nextInt();
        int x = 3;
        System.out.println("Value of polynomial is: " + evalPoly(arr,x));
    }
}

