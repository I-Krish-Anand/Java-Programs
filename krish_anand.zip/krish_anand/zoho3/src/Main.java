import java.util.*;
public class Main {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n= sc.nextInt();
        int temp=n,rev=0;
        while(temp>=1)
        {
            rev*=10;
            rev+=temp%10;
            temp/=10;
        }
        System.out.print(n-rev);
    }
}