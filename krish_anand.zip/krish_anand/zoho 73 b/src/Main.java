import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Row size");
        int m= sc.nextInt();
        System.out.println("Column size:");
        int n=sc.nextInt();
        System.out.println("Row size");
        int m1= sc.nextInt();
        System.out.println("Column size:");
        int n1=sc.nextInt();
        int[][]a=new int[m][n];
        int[][]b=new int[m1][n1];
        for (int i=0;i<m;i++)
            for(int j=0;j<n;j++)
                a[i][j]=sc.nextInt();
        for (int i=0;i<m;i++)
            for(int j=0;j<n;j++)
                b[i][j]=sc.nextInt();
        if(a.length==b.length && a[0].length==b[0].length) {
            int[][] c = new int[m][n];
            for (int i = 0; i < a.length; i++) {
                for (int j = 0; j < a[0].length; j++) {
                    c[i][j] = a[i][j] + b[i][j];
                }
            }
            //print
            for (int i = 0; i < a.length; i++) {
                for (int j = 0; j < a.length; j++)
                    System.out.print(c[i][j] + " ");
                System.out.println();
            }
        }
        else System.out.println("Invalid");
    }
}