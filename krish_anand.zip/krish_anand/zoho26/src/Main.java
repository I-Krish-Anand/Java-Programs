public class Main {
    public static void main(String[] args)
    {
        long a1=Long.MAX_VALUE;
        long a2=Long.MAX_VALUE;
        int b1=Integer.MAX_VALUE;
        int b2=Integer.MIN_VALUE;
        System.out.println("Range of int is:"+b2+" to "+b1);
        System.out.println("Whereas range long is:"+a2+" to "+a1);
    }
}