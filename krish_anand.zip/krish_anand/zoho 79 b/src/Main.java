import java.util.*;
public class Main {
    static boolean matrixRec(int i,int j,int[][]a,boolean[][]map,boolean flag)
    {
        if(flag)
        {
            if(i==a.length || j==a[0].length||i==-1||j==-1)
                return true;

            if(map[i][j])
                return true;

            map[i][j]=true;

            if(!((i==j && a[i][j]==1) || a[i][j]==0))
                flag = false;


            flag= matrixRec(i, j + 1, a, map, flag);
            flag= matrixRec(i + 1, j, a, map, flag);
            flag= matrixRec(i, j - 1, a, map, flag);
            flag= matrixRec(i - 1, j, a, map, flag);
        }
        return flag;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Row size");
        int m= sc.nextInt();
        System.out.println("Column size:");
        int n=sc.nextInt();
        if(m==n)
        {
            int[][] a = new int[m][n];
            System.out.println("Matrix elements");

            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    a[i][j] = sc.nextInt();
            boolean map[][]=new boolean[a.length][a[0].length];
            boolean flag=matrixRec(0,0,a,map,true);


            if (flag)
                System.out.println("Identity Matrix");
            else if (!flag)
                System.out.println("Not a Identity Matrix");
        }
        else System.out.println("Not a Identity Matrix");
    }
}