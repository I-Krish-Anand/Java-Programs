public class Main {

    static int swap(char[]arr,int j,int i)
    {
        if(arr[j]<arr[i]) {
            char tem = arr[j];
            arr[j] = arr[i];
            arr[i] = tem;
        }
        return  i+1;
    }
    static int stringSort(char[] arr,int i,int j) {

        if ( i-1==j)
            return i;
        return swap(arr, j,stringSort(arr,i-1,j));

    }
    static String outerLoop(char[]arr,int i)
    {
        if(i==0)
            return new String(arr) ;
        stringSort(arr,arr.length, arr.length-i);
        return outerLoop(arr,i-1);
    }
    public static void main(String[] args)
    {
        //using backward recursive selection sort algorithm
        String a= "welcometozohogradschools";
        System.out.println(outerLoop(a.toCharArray(), a.length()));

    }
}