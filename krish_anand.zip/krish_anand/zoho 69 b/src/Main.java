import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int[]arr={1,2,3,4,5,6,7};
        int n=arr.length;
        int[]temp=new int[n];
        int rot=sc.nextInt();
        rot= n-rot%n;
        int k=0;
        for(int i=rot%n;k<n;i=(i+1)%n)
            temp[k++]=arr[i];
        //print array elements
        for(int i:temp)
            System.out.print(i+" ");
    }
}