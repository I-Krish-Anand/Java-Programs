import java.util.*;
public class Main {
    static double findArea(double radius)
    {
        return Math.PI*radius*radius;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Radius of outer circle:");
        double radius1=sc.nextDouble();
        System.out.println("Radius of inner circle:");
        double radius2=sc.nextDouble();
        System.out.format("Area between concentric circles:%.2f",(float)(findArea(radius1)-findArea(radius2)));
    }
}