import java.util.*;
public class Main {
    public static void main(String[] args) {
        // using arraycopy
        Scanner sc=new Scanner(System.in);
        int n =sc.nextInt();
        int[]a=new int[n];
        for(int i=0;i<n;i++)
            a[i]=sc.nextInt();
        int[]b=new int[n];
        System.arraycopy(a,0,b,0,n);
        System.out.println("Original Array");
        for(int i:a)
            System.out.print(i+" ");
        System.out.println("\nCopied Array");
        for(int i:b)
            System.out.print(i+" ");

    }
}