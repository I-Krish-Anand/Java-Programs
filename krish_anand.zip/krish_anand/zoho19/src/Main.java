public class Main {
    public static void main(String[] args) {
        int a=28;
        System.out.println(a+= a++ + ++a + --a +a--);
    }
}