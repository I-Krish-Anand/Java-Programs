import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        char ch=sc.next().charAt(0);
        String a=String.valueOf(ch);
        if(a.equalsIgnoreCase("a")||a.equalsIgnoreCase("e")||a.equalsIgnoreCase("i")||a.equalsIgnoreCase("o")
        ||a.equalsIgnoreCase("u"))
            System.out.println(ch+" is a vowel");
        else
            System.out.println(ch+" is a consonant");
    }
}