public class Main {
    public static void main(String[] args) {
        for(int i=65;i<97;i++)
        {
            System.out.print((char) i);
        }
    }
}