import java.util.Arrays;

public class Main {

    static void swap(int[] arr,int i,int j)
    {
        int temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }

    static void stringSort(int[] arr)
    {
        int n=arr.length;
        for(int i=0;i<n;i++)
        {
            int min=i;
            for(int j=i+1;j<n;j++)
            {
                if(arr[j]<(arr[min]))
                    min=j;
            }
            swap(arr,i,min);
        }
    }
    public static void main(String[] args)
    {
        //  selection  sort
        int[]arr={2,1,3,4,8,7,6,5,9,0};
        stringSort(arr);
        System.out.println(Arrays.toString(arr));
    }
}