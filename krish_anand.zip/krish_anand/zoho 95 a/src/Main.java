import java.util.*;
public class Main {
    static boolean isPalindrome(String a)
    {
        int i=0,j=a.length()-1;
        a=a.toLowerCase();
        while(i<j)
        {
            if(a.charAt(i++)!=a.charAt(j--))
                return false;
        }
        return true;
    }
    public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
       String a=sc.next();
       System.out.println(a+" is Palindrome? "+isPalindrome(a));

    }
}