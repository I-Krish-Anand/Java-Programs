import java.util.Scanner;
class Main {
   static int binarySearch(char arr[], int i, int j, char x)
    {
        if (j >= i)
        {
            int mid = i + (j - i) / 2;
            if (arr[mid]==x)
                return mid;
            if (arr[mid]>x)
                return binarySearch(arr, i, mid - 1, x);
            else
            return binarySearch(arr, mid + 1, j, x);
        }
        return -1;
    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        String a=sc.next();
        char  x = sc.next().charAt(0);
        int n=a.length();
        int result = binarySearch(a.toCharArray(), 0, n - 1, x);
        if (result == -1)
            System.out.println("Element not present");
        else
            System.out.println("Element found at index " + result);
    }
}
