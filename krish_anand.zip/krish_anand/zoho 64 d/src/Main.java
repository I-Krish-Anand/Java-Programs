import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // variable reference
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int[]a=new int[n];
        for(int i=0;i<n;i++)
            a[i]=sc.nextInt();
        int[] b=a;
        System.out.println("Original array:");
        for(int i:a)
            System.out.print(i+" ");
        System.out.println("\nCopied array:");
        for(int i:b)
            System.out.print(i+" ");
        //any change in one array is reflected in both arrays Eg:
        a[0]=15;
        System.out.println("\nOriginal array with changed value:");
        for(int i:a)
            System.out.print(i+" ");
        System.out.println("\nCopied array where value in the corresponding index also changes:");
        for(int i:b)
            System.out.print(i+" ");
    }
}