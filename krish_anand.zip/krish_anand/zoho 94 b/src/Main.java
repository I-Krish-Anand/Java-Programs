import java.util.Scanner;
public class Main {
    static String sort(char[] arr)
    {
        for(int i=0;i< arr.length;i++)
        {
            int min=i;
            for(int j=i+1;j< arr.length;j++)
            {
                if(arr[j]<arr[min])
                    min=j;

            }
            char temp=arr[i];
            arr[i]=arr[min];
            arr[min]=temp;
        }
        return new String(arr);
    }
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String a=sc.next();
        String b=sc.next();
        char[] arr=a.toCharArray();
        char[] brr=b.toCharArray();
        if(sort(arr).equals(sort(brr)))
            System.out.print(a+" "+b+" are anagram of each other");
        else
            System.out.print(a+" "+b+" are not anagram of each other");
    }
}