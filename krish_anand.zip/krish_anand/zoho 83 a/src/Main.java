import java.util.Scanner;

public class Main
{
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        int row,col;
        row=sc.nextInt();
        col=sc.nextInt();
        if(row != col ){
            System.out.println("upper triangular matrix can't be formed");
        }
        else {
            int[][]a=new int[row][col];
            for(int i=0;i<a.length;i++)
            {
                for (int j=0;j<a[0].length;j++)
                    a[i][j]=sc.nextInt();
            }
            for(int i = 0; i < a.length; i++)
            {
                for(int j = 0; j < a[0].length; j++)
                {
                    if(i<=j)
                        System.out.print(a[i][j]+" ");
                    else
                        System.out.print("0 ");
                }
                System.out.println();
            }
        }
    }
}