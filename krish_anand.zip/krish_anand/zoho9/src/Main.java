import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    /*concept of List is used since the array size cannot be modified later, can also solve by using arrays but requires extra space "*/
    static void merge(int[]a,int[]b,List<Integer> ls)
    {
        int i=0;
        int j=0;
        while(i<a.length && j<b.length)
        {
            if(a[i]<b[j])
                ls.add(a[i++]);

            else if(a[i]>b[j])
                ls.add(b[j++]);

            else if (a[i] == b[j]) {
                ls.add(a[i++]);
                j++;
            }
        }
        while(i<a.length)
            ls.add(a[i++]);
        while(j<b.length)
            ls.add(b[j++]);

    }
    public static void main(String[] args)
    {

        //int[]arr={ 2,4,5,6,7,9,10,13};
        //int[]brr={ 2,3,4,5,6,7,8,9,11,15};
        Scanner sc=new Scanner(System.in);
        System.out.println("Size of array 1:");
        int n=sc.nextInt();
        System.out.println("Size of array 2:");
        int m= sc.nextInt();
        int[]arr=new int[n];
        int[]brr=new int[m];
        for(int i=0;i<n;i++)
            arr[i]= sc.nextInt();
        for(int i=0;i<m;i++)
            brr[i]= sc.nextInt();

        List<Integer> ls=new ArrayList<>();
        merge(arr,brr,ls);
        System.out.println(ls);
    }
}