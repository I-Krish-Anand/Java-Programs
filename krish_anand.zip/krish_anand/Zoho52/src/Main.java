import java.util.*;
public class Main {
    public static void main(String[] args)
    {
         Scanner sc=new Scanner(System.in);
         String a=sc.nextLine();
         String[]arr=a.split(" ");
         reverse(arr,0);
    }
    static void reverse(String[]arr,int i)
    {
        if(i== arr.length)
            return;

        reverse(arr,i+1);
        System.out.print(arr[i]+" ");
    }
}