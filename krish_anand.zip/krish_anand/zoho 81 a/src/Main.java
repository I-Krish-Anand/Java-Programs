import java.util.*;
public class Main
{
    static boolean matrixRec(int i,int j,int[][]a,int[][]b,boolean[][]map,boolean flag)
    {
        if(flag)
        {
        if(i==a.length || j==a[0].length||i==-1||j==-1)
            return true;

        if(map[i][j])
            return true;

        map[i][j]=true;

        if(a[i][j]!=b[i][j])
            flag = false;


         flag= matrixRec(i, j + 1, a, b, map, flag);
         flag= matrixRec(i + 1, j, a, b, map, flag);
         flag= matrixRec(i, j - 1, a, b, map, flag);
         flag= matrixRec(i - 1, j, a, b, map, flag);
        }
        return flag;
    }
    public static void main(String[] args)
    {

        int[][]a={{1,2,3},
                {4,5,6},
                {7,8,9}};

        int[][]b={{1,2,3},
                {4,5,6},
                {7,8,9}};
        boolean map[][]=new boolean[a.length][a[0].length];
        if(a.length==b.length &&a[0].length==b[0].length)
        System.out.println("Are Matrices equal?:"+matrixRec(0,0,a,b,map,true));
        else
            System.out.println("Are Matrices equal?:false");
    }
}
