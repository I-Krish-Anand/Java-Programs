public class Main
{

    public static void main(String[] args)
        {
           int[]arr={91,1,3,4,7,38,45,89,29,9,73,90};
           int min1=Integer.MAX_VALUE;
           int min2=Integer.MAX_VALUE;
           for (int i=0;i<arr.length;i++)
           {
             if(arr[i]<min1)
             {
              min2=min1;
              min1=arr[i];
             }
             else if(arr[i]>min1 && arr[i]<min2)
              min2=arr[i];
           }
        System.out.println("Second Maximum element in the array is:"+min2);
        }
}