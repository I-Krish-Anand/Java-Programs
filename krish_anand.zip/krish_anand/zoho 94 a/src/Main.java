import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        String a=sc.next();
        String b=sc.next();
        char[] arr=a.toCharArray();
        char[] brr=b.toCharArray();
        Arrays.sort(arr);
        Arrays.sort(brr);
        if(new String(arr).equals(new String(brr)))
            System.out.print(a +" "+b+" are anagram of each other");
        else
            System.out.print(a +" "+b+" are not anagram of each other");

    }
}