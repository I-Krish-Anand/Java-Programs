public class Main{
    public static void main (String[] args)
    {
        //square matrix
        int[][]a={{1,2,3},
                 {4,5,6},
                 {7,8,9}};
        int rowSum,colSum;
        for(int i =0;i<a.length;i++)
        {
            rowSum=0;
            colSum=0;
            for(int j=0;j<a[0].length;j++)
            {
                rowSum+=a[i][j];
                colSum+=a[j][i];

            }
            System.out.println("Sum of row:"+(i+1)+" is "+rowSum);
            System.out.println("Sum of column:"+(i+1)+" is "+colSum);

        }
    }
}