import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int dividend=sc.nextInt();
        int divisor=sc.nextInt();
        int quotient=dividend/divisor;
        int remainder=dividend%quotient;
        System.out.println("Quotient is:"+quotient+" Remainder is:"+remainder);

    }
}