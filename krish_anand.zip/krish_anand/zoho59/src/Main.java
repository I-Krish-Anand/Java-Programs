import java.util.*;
public class Main {
    static int calc(String a,String b)
    {
        int k=0,index=-1;
        for(int i=0;i<a.length();i++)
        {
            if(k==b.length())
                return index;
            if(a.charAt(i)==b.charAt(k))
            {
                if(index==-1)
                    index=i;
                k++;
            }
            else {
                k = 0;
                index = -1;
            }
        }
        if(k==b.length())
            return index;
        else
            return -1;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String a=sc.next();
        String b= sc.next();
        System.out.println(calc(a,b));
    }
}