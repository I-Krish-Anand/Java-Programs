import java.util.*;
public class Main {
    public static void main(String[] args) {
        int[]arr={143,56,74,35,24,674,355,77};
        int min=Integer.MAX_VALUE;
        for(int i:arr)
        {
            if(i<min)
                min=i;
        }
        System.out.print("Smallest Value in the array is:"+min);
    }
}