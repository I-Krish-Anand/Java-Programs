import java.util.Arrays;

public class Main {

    static void swap(String[] arr,int i,int j)
    {
        String temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }

    static void stringSort(String[] arr)
    {
        int n=arr.length;
        for(int i=0;i<n;i++)
        {
            int min=i;
            for(int j=i+1;j<n;j++)
            {
                if(arr[j].compareTo(arr[min])<0)
                    min=j;
            }
            swap(arr,i,min);
        }
    }
    public static void main(String[] args)
    {
        //  bubble sort
        String a="welcome you all to zoho grad studies";
        String[]arr=a.split(" ");
        stringSort(arr);
        System.out.println(Arrays.toString(arr));
    }
}