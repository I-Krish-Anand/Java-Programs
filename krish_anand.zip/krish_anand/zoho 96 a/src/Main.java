import java.util.Scanner;

public class Main {
    static void search(char[]a,char ele)
    {
        for(int i = 0;i<a.length;i++)
        {
            if(a[i]==ele)
            {
                System.out.print("Element "+ele + " found "+" at "+i);
                return;
            }
        }
        System.out.print("Element not found");
    }
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter string");
        String a=sc.next();
        System.out.println("Enter element to search");
        char ele=sc.next().charAt(0);
        search(a.toCharArray(),ele);
    }
}