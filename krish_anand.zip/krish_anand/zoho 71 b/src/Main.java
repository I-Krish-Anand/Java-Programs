public class Main {
    public static void main(String[] args) {
        int[]arr={91,1,4,7,38,45,89,29,9,73,90,92};
        for(int i=0;i<arr.length;i++)
        {
            int max=i;
            for(int j=i+1;j<arr.length;j++)
            {
                if(arr[j]<arr[max])
                    max=j;
            }
            int temp=arr[i];
            arr[i]=arr[max];
            arr[max]=temp;

        }
        System.out.println("Second Smallest Element is:"+arr[1]);

    }
}