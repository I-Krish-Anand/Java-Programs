public class Main
{
    static int matrixRec(int i,int j,int[][]a,boolean[][]map)
    {
        if(i==a.length || j==a[0].length||i==-1||j==-1)
            return 0;

        if(map[i][j])
            return 0;

        int even=0;

        if(a[i][j]%2==0)
            even++;

        map[i][j]=true;

        even+=matrixRec(i,j+1,a,map);
        even+=matrixRec(i+1,j,a,map);
        even+=matrixRec(i,j-1,a,map);
        even+=matrixRec(i-1,j,a,map);
        return even;
    }
    public static void main(String[] args) {

        int a[][] = {{15, 9, 17},
                {6, 14, 16},
                {4, 12, 10}};

            boolean[][] map=new boolean[a.length][a[0].length];
            int i=matrixRec(0,0,a,map);
            System.out.println("Even elements:"+i);
            System.out.println("Odd elements:"+((a.length*a[0].length)-i));

    }
}