public class Main {
    static int findSum(int[] arr,int i)
    {
        if(i==arr.length)
            return 0;
         return arr[i]+ findSum(arr,i+1);
    }
    public static void main(String[] args) {

        int[]arr={1,3,4,5,6,7,2,9,10,8};
        System.out.print(findSum(arr,0));
    }
}