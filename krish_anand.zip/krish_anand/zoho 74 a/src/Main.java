public class Main {
    static void matrixRec(int i,int j,int[][]a,int[][]b,boolean[][]map,int[][]res)
    {
        if(i==a.length || j==a[0].length||i==-1||j==-1)
            return;

        if(map[i][j])
            return;

        for (int k = 0; k < b.length; k++)
            res[i][j] += a[i][k] * b[k][j];
        map[i][j]=true;

        matrixRec(i,j+1,a,b,map,res);
        matrixRec(i+1,j,a,b,map,res);
        matrixRec(i,j-1,a,b,map,res);
        matrixRec(i-1,j,a,b,map,res);
    }
    public static void main(String[] args)
    {
        //square matrix of equal length
        int a[][] = { { 1, 2, 3, 4 },
                { 1, 2, 3, 4 },
                { 1, 2, 3, 4 },
                { 1, 2, 3, 4 } };

        int b[][] = { { 1, 2, 3, 4 },
                { 1, 2, 3, 4 },
                { 1, 2, 3, 4 },
                { 1, 2, 3, 4 } };
        int M1= a.length;
        int N1=a[0].length;
        int M2= b.length;
        int N2=b[0].length;
        if(M1==N2 && N1==M2) {
            boolean map[][] = new boolean[a.length][a[0].length];
            int res[][] = new int[a.length][a[0].length];
            matrixRec(0, 0, a, b, map, res);

            System.out.println("Result matrix" + " is ");
            for (int i = 0; i < res.length; i++) {
                for (int j = 0; j < res[0].length; j++)
                    System.out.print(res[i][j] + " ");
                System.out.println();
            }
        }
        else
            System.out.println("Invalid input");
    }
}

