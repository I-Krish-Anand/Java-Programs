import java.util.*;
public class Main {
     static void removeDuplicates(int[] a)
    {
        List<Integer> ls = new ArrayList<>();
        for (int i:a)
        {
            if (!ls.contains(i))
                ls.add(i);
        }
        System.out.print(ls);
    }
    public static void main(String[] args)
    {
        int a[] = {1,4,5,6,7,7,4,4,6,7,2,3};
        removeDuplicates(a);
    }
}
