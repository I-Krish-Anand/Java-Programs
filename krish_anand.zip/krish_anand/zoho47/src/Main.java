import java.util.*;
public class Main {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        for(int i=1;i<=n;i++)
        {
            int spc=1,j;

            while(spc++<=n-i)
                System.out.print(" ");

            for( j=1;j<=i;j++)
                System.out.print(j);

            for(j=i-1;j>=1;j--)
                System.out.print(j);

            System.out.println();

        }

    }
}