public class Main {
    public static void main(String[] args) {
        int a=2,b=2;
        System.out.println("a:"+a+" b:"+b);
        System.out.println(++a-b--);
        System.out.println("Values of a and b after evaluation:"+a+" "+b);
        a=2;b=2;
        System.out.println("a:"+a+" b:"+b);
        System.out.println(a%b++);
        System.out.println("Values of a and b after evaluation:"+a+" "+b);
        a=2;b=2;
        System.out.println("a:"+a+" b:"+b);
        System.out.println(a*=b+5);
        System.out.println("Values of a and b after evaluation:"+a+" "+b);
        int x=69>>>2;
        System.out.println(x);
    }
}