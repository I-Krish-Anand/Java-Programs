import java.util.*;
public class Main
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int count=0;
        int row=-1;
        //finding no of rows
        for(int i=0;i<n;i++) {
            for (int j = 0; j <= i; j++)
                count++;
            if (count >= n)
            {
                row = i + 1;
                break;
            }
        }
        count=1;
        for(int i=1;i<=row;i++)
        {
            int sp=i;
            //white spacing
            while(sp++<row)
                System.out.print(" ");

            for(int j=1;j<=i;j++)
                System.out.print(count++ +" ");

            System.out.println();
        }
    }
}