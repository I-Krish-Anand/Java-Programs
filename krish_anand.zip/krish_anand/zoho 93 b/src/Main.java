
    public class Main {
        static char stringSort(char[] arr,int i) {
            if (i == 0)
                return arr[i];

            if (arr[i]>(stringSort(arr, i - 1)))
            {
                char temp=arr[i];
                arr[i]=arr[i-1];
                arr[i-1]=temp;
            }
            return arr[i];

        }
        static  String outerLoop(char[]arr,int i)
        {
            if(i==0)
                return new String(arr);
            stringSort(arr,i);
            return outerLoop(arr,i-1);
        }
        public static void main(String[] args)
        {
            // recursive bubble sort using reverse order
            String a="welcomeyoualltozohogradstudies";
            System.out.println(outerLoop(a.toCharArray(), a.length() - 1));
        }
    }