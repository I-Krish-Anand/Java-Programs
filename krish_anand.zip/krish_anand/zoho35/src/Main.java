import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int no=sc.nextInt();
        int fact=1;
        for(int i=1;i<=no;i++)
            fact*=i;
        System.out.println("Factorial of "+no+" is:"+fact);
        String a= String.valueOf(fact);
        int sum=0;
        for(char i:a.toCharArray())
        {
            sum+=i-48;
        }
        System.out.println("Sum of elements in factorial is:"+sum);
    }
}