import java.util.Scanner;

public class Main {
    static void func(String a,int i)
    {
        if(i==a.length())
            return;
        if(a.charAt(i)>=97 && a.charAt(i)<=122)
            System.out.print((char)(a.charAt(i)-32));
        else
            System.out.print(a.charAt(i));
        func(a,i+1);
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter String");
        String a=sc.nextLine();
        func(a,0);
    }
}