import java.util.Arrays;
public class Main {

    static void swap(int[]a,int i, int j)
    {
        int temp=a[i];
        a[i]=a[j];
        a[j]=temp;
    }
    static void sort(int[] a,int beg,int end)
    {
        int k;
        if (beg < end)
        {
            k = quicksort(a, beg, end);
            sort(a, beg, k);
            sort(a, k+1 , end);
        }
    }
    static int quicksort(int[]a,int i, int j)
    {
        int pivot=i;
        while(i<j)
        {
            do
            {
                i++;
            }while(i<j && a[i]<a[pivot]);

            do
            {
                j--;
            }while(j>=i && a[j]>a[pivot] );

            if(i<j)
                swap(a,i,j);
        }
        swap(a,j,pivot);
        return j;
    }
    public static void main(String[] args)
    {
        // quicksort
        int[]arr={1,5,6,2,3,8,9,7};
        sort(arr,0,arr.length);
        System.out.println(Arrays.toString(arr));
    }
}