public class Main {
    public static void main(String[] args) {
        int[]arr={143,56,74,35,24,674,355,77};
        System.out.println("Elements in array are:");
        for(int i:arr)
            System.out.print(i+" ");
        System.out.println("Number of Elemennts:"+arr.length);
    }
}