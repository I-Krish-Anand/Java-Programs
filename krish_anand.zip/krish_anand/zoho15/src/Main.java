import java.util.*;
public class Main {
    static double areaOfCylinder(double radius,double height)
    {
        return 2*Math.PI*radius*(radius+height);
    }
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        double radius=sc.nextDouble();
        double height=sc.nextDouble();
        System.out.println(areaOfCylinder(radius,height));
    }
}