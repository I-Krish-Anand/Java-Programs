public class Main {
    public static void main(String[] args)
    {
        int[] a = { 1, 1, 5, 2, 4, 5, 2, 3, 6, 8, 9, 3, 7};
        int max = 0;
        for (int i:a)
        {
            if(i>max)
               max=i ;
        }
        int[] freq = new int[max + 1];
        for (int i:a)
            freq[i]++;

        for (int i = 0; i < freq.length; i++)
        {

            if (freq[i] > 1) {
                System.out.print(i + " ");
            }
        }
    }
}
