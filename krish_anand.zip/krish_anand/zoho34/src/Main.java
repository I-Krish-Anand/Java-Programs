import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int limit=sc.nextInt();
        int sum=0;
        for(int i=1;i<=limit;i++)
           sum+=i;
        System.out.println("The sum of first "+limit+" natural numbers is:"+sum);
        String a= String.valueOf(sum);
        int max=Integer.MIN_VALUE;
        for(char i:a.toCharArray())
        {
            if(i-48>max)
                max=i-48;
        }
        System.out.println("Max element in sum is:"+max);
    }
}