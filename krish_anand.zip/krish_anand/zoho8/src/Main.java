   public class Main {
    static int a;
    static class Test
    {
        static
        {
            a=5;
        }
        static void calc()
        {
            a++;
            System.out.println(a);
        }
    }
    public static void main(String[] args)
    {

        Test.calc();
        Test a=new Test();
        a.calc();
        Test b=new  Test();
        b.calc();
    }
}