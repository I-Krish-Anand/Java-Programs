public class Main {
    public static void main(String[] args) {
        int[]arr={1,1,1,2,5,7,7,3,3,5,7,9,2,2,15,23,56};
        int[]freq=new int[arr.length];
        for(int i=0;i<arr.length;i++)
        {
                if(freq[i]==0) {
                    int count = 1;
                    for (int j = i + 1; j < arr.length; j++) {
                        if (arr[i] == arr[j]) {
                            count++;
                            freq[j] = -1;
                        }
                    }
                    freq[i] = count;
                }

        }
        for(int i=0;i<arr.length;i++)
        {
            if(freq[i]>0)
             System.out.println(arr[i]+" Frequency: "+freq[i]);
        }
    }
}