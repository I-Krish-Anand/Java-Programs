public class Main {
    public static void main(String[] args) {
        int[]arr={1,1,5,6,7,6,3,4,5,6,2,4,7,4,3};
        int max=Integer.MIN_VALUE;
        for(int i:arr)
        {
            if(i>max)
                max=i;
        }
        int[]count=new int[max+1];
        for(int i:arr)
            count[i]++;
        for (int i=0;i<count.length;i++)
        {
            if(count[i]>0)
            System.out.println("Frequency of Element"+i+" is:"+count[i]);
        }
    }
}