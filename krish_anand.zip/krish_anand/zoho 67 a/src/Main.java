import java.util.*;
public class Main {
    public static void main(String[] args)
    {
        List<Integer> ls=new ArrayList<>();
        int[]arr={1,2,15,5,6,8,3,1,5,7,3,6,2,1};
        for(int i=0;i<arr.length;i++)
        {
            if(!ls.contains(arr[i])) {
                for (int j = i + 1; j < arr.length; j++) {
                    if (arr[i] == arr[j]) {
                        System.out.println("Duplicate Entry: " + arr[i]);
                        break;
                    }
                }
                ls.add(arr[i]);
            }

        }

    }
}