import java.util.*;
class Main {

    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String str =sc.nextLine() ;
        List<String> ls = new ArrayList<>();
        int index=0,i;
        for( i=0;i<str.length();i++)
        {
            if(str.charAt(i)==' ')
            {
                ls.add(str.substring(index, i));
                index=i+1;
            }
        }
        ls.add(str.substring(index));
        String[] arr = new String[ls.size()];
        int k = 0;
        for (String a : ls)
            arr[k++] = a;
        System.out.println(Arrays.toString(arr));
    }
}
