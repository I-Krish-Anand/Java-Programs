import java.util.*;
public class Main {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        char ch=sc.next().charAt(0);
        char in;
        for(;ch>='A';ch--)
        {
            for (in = 'A';in <= ch;in++)
                System.out.print(ch);
            System.out.print("\n");
        }

    }
}