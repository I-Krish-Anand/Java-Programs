public class Main {
    public static void main(String[] args) {
        int[] a = {1, 1, 5, 6, 7, 6, 3, 4, 5, 6, 2, 4, 7, 4, 3, 9, 12, 15};
        for (int j = 0; j < a.length; j++) {
            for (int k = j + 1; k < a.length; k++) {
                if (a[j] == a[k] ) {
                        System.out.println(a[j]);
                        break;
                }

            }

        }
    }
}