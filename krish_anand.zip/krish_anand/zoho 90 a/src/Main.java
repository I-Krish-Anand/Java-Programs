import java.util.Arrays;
import java.util.Scanner;

public class Main {

    static void swap(String[]a,int i, int j)
    {
        String temp=a[i];
        a[i]=a[j];
        a[j]=temp;
    }
    static void sort(String[] a,int beg,int end)
    {
        int k;
        if (beg < end)
        {
            k = quicksort(a, beg, end);
            sort(a, beg, k);
            sort(a, k+1 , end);
        }
    }
    static int quicksort(String[]a,int i, int j)
    {
        int pivot=i;
        while(i<j)
        {
            do
            {
                i++;
            }while(i<j && a[i].compareTo(a[pivot])<=0);

            do
            {
                j--;
            }while(j>=i && a[j].compareTo(a[pivot])>0 );

            if(i<j)
                swap(a,i,j);
        }
        swap(a,j,pivot);
        return j;
    }
    public static void main(String[] args)
    {
        // quicksort
        Scanner sc=new Scanner(System.in);
        String a=sc.nextLine();
        String[]arr=a.split(" ");
        sort(arr,0,arr.length);
        System.out.println(Arrays.toString(arr));
    }
}