public class Main {
    public static void main(String[] args)
    {
        //Method 2 using loops
        int[]arr={1,2,3,4,5,6,7,8,9,10};
        System.out.println("Elements at odd position");
        for(int i=0;i<arr.length;i+=2)
            System.out.print(arr[i]+" ");
        System.out.println("\nElements at even position");
        for(int i=1;i<arr.length;i+=2)
            System.out.print(arr[i]+" ");
    }
}