public class Main {
    public static void main(String[] args)
    {
        int[][] a = { { 1, 2, 3, 4 },
                { 1, 2, 3, 4 },
                { 1, 2, 3, 4 },
                { 1, 2, 3, 4 } };

        int[][] b = { { 1, 2, 3, 4 },
                { 1, 2, 3, 4 },
                { 1, 2, 3, 4 },
                { 1, 2, 3, 4 } };
        int M1= a.length;
        int N1=a[0].length;
        int M2= b.length;
        int N2=b[0].length;
        if(M1==N2 && N1==M2) {
            int[][] res= new int[M1][N1];
            for (int i = 0; i < M1; i++) {
                for (int j = 0; j < N1; j++) {
                    for (int k = 0; k < N1; k++)
                        res[i][j] += a[i][k] * b[k][j];
                }
            }

            System.out.println("Result matrix" + " is ");
            for (int i = 0; i < M1; i++) {
                for (int j = 0; j < N1; j++)
                    System.out.print(res[i][j] + " ");
                System.out.println();
            }
        }
        else
            System.out.println("Invalid input");
    }
}

