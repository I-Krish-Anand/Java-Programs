public class Main
{
    static int matrixRec(int i,int j,int[][]a,boolean[][]map)
    {
        if(i==a.length || j==a[0].length||i==-1||j==-1)
            return 0;

        if(map[i][j])
            return 0;

        int zeros=0;

        if(a[i][j]%2==0)
            zeros++;

        map[i][j]=true;
        zeros+=matrixRec(i,j+1,a,map);
        zeros+=matrixRec(i+1,j,a,map);
        zeros+=matrixRec(i,j-1,a,map);
        zeros+=matrixRec(i-1,j,a,map);
        return zeros;
    }
    public static void main(String[] args)
    {
        int m, n;
        int a[][] = new int[][]{{1,0,0},
                {0,2,0},
                {0,0,3}};
        m=a.length;
        n=a[0].length;
        boolean[][]map=new boolean[a.length][a[0].length];
        int count=matrixRec(0,0,a,map);
        if(count>((m*n)/2))
            System.out.println("It is a sparse matrix");
        else
            System.out.println("It is not a sparse matrix");
    }
}