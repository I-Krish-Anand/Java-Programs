import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
       //using ascii value of A which is 65 and a which is 97
        Scanner sc=new Scanner(System.in);
        char ch=sc.next().charAt(0);
        System.out.println(ch+" in capital:"+(char)(ch-32));
    }
}