import java.util.*;

public class Main {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String a=sc.nextLine();
        String []arr=a.split(" ");
            System.out.print(Arrays.toString(arr));

    }
}