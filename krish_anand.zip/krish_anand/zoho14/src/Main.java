import java.util.*;
public class Main {
    static double areaOfRectangle(double a,double b)
    {
        return a*b;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("L:");
        double a=sc.nextDouble();
        System.out.println("B");
        double b=sc.nextDouble();
        System.out.println("Area:"+areaOfRectangle(a,b));
    }
}