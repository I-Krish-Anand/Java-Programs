public class Main {
    public static void main(String[] args) {
        int[]arr={1,2,45,2,34,5,455,34,57,5,21,3,8};
        int sum=0;
        for(int i:arr)
         sum+=i;

        System.out.println("Sum of elements in the array is:"+sum);
    }
}