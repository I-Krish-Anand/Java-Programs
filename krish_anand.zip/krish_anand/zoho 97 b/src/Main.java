/*package whatever //do not write package name here */

import java.io.*;
import java.util.*;

class Main {

    static int binarySearch(char a[], char x)
    {
        int i = 0, j = a.length - 1;
        while (j>=i)
        {
            int mid = i+(j - i) / 2;
            if(a[mid]==x)
                return mid;
            if (a[mid] < x)
                i = mid + 1;
            else
                j = mid-1;
        }
        return -1;
    }


    public static void main (String[] args) {

        Scanner sc=new Scanner(System.in);
        String a=sc.next();
	    char x=sc.next().charAt(0);
        int result=binarySearch(a.toCharArray(), x);
        if (result == -1)
            System.out.println("Element not present");
        else
            System.out.println("Element found at index " + result);
    }
}
