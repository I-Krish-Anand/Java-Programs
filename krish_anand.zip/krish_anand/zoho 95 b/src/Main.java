import java.util.*;
public class Main {

    static String reverse(String a)
    {
        String rev="";
        for(int i=a.length()-1;i>=0;i--)
            rev+=a.charAt(i);
        return  rev;
    }

    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String a=sc.next();
        a=a.toLowerCase();
        String b=reverse(a);
            System.out.println(a+" is Palindrome? "+a.equals(b));
    }
}