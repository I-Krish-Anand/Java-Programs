import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int[]arr={1,2,3,4,5,6,7};
        int rot=sc.nextInt();
        while (rot-->0)
        {
            int beg=arr[0],i;
            for( i=0;i<arr.length-1;i++)
                arr[i]=arr[i+1];
            arr[i]=beg;
        }
        //print
        for(int k:arr)
            System.out.print(k+" ");
    }
}