public class Main {
    static void swap(int i,int j,int[]arr)
    {
        int temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }
    public static void main(String[] args) {
        //int[] arr = {13, 2, 4, 15, 12, 10, 5};
        int[] arr= {1,2,3,4,5,6,7,8,9};
        System.out.println("Before Sorting");
        for(int i:arr)
            System.out.print(i+" ");
        for (int i = 0; i < arr.length; i += 2)
        {
            int max = i, j;
            for (j = i + 2; j < arr.length; j += 2) {
                if (arr[j] > arr[max])
                    max = j;
            }
            swap(i, max, arr);
        }
        for (int i = 1; i < arr.length; i += 2)
        {
            int min = i, j;
            for (j = i + 2; j < arr.length; j += 2)
            {
                if(arr[j]<arr[min])
                    min=j;
            }
            swap(i, min, arr);
        }
        System.out.println("\nAfter Sorting");
        for(int i:arr)
        System.out.print(i+" ");
    }

}