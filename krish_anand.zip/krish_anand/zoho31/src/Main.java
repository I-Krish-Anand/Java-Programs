import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Coefficient of x^2:");
        double a=sc.nextDouble();
        System.out.println("Coefficient of x:");
        double b=sc.nextDouble();
        System.out.println("Constant value:");
        double c=sc.nextDouble();
        double sqrt=Math.sqrt(b*b-4.0*a*c);
        if(sqrt>0.0) {
            double root1 = (-b + sqrt) / 2.0 * a;
            double root2 = (-b - sqrt) / 2.0 * a;
            System.out.println("The roots of the quadratic equation are:" + root1 + " " + root2);
        }
        else if(sqrt==0.0)
        {
            double root = (-b ) / 2.0 * a;
            System.out.println("The root is"+root);
        }
        else
        {
            System.out.println("Unreal roots");
        }


    }
}