import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        char[] ch={'w','e','l','c','o','m','e'};
        for (char i:ch)
            System.out.print(i+" ");
        

    }
}