import java.util.*;
public class Main {
    static double areaOfSquare(double a)
    {
        return a*a;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter side length:");
        double a=sc.nextDouble();
        System.out.println(areaOfSquare(a));
    }
}