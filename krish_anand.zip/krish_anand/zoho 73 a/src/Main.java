import java.util.*;
public class Main
{
    static void matrixRec(int i,int j,int[][]a,int[][]b,boolean[][]map,int[][]res)
    {
        if(i==a.length || j==a[0].length||i==-1||j==-1)
            return;

        if(map[i][j])
            return;

        res[i][j]=a[i][j]+b[i][j];
        map[i][j]=true;

        matrixRec(i,j+1,a,b,map,res);
        matrixRec(i+1,j,a,b,map,res);
        matrixRec(i,j-1,a,b,map,res);
        matrixRec(i-1,j,a,b,map,res);
    }
    public static void main(String[] args)
    {

        int[][]a={{1,2,3},
                {4,5,6},
                {7,8,9}};

        int[][]b={{1,2,3},
                {4,5,6},
                {7,8,9}};
        if(a.length==b.length &&a[0].length==b[0].length) {
            boolean map[][] = new boolean[a.length][a[0].length];
            int res[][] = new int[a.length][a[0].length];
            matrixRec(0, 0, a, b, map, res);
            for (int i = 0; i < a.length; i++) {
                for (int j = 0; j < a.length; j++)
                    System.out.print(res[i][j] + " ");
                System.out.println();
            }
        }
        else System.out.println("Invalid input");
    }
}
