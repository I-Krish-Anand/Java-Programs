import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        for(int j=1;j<n*2;j++)
        {
            int k;
            if(j>n)
                k=j%n;
            else
             k=(n*2-j)%n;

            for (int i = 0; i < n * 2; i++)
            {
                if(i>k && i<(n*2-1-k) )
                    System.out.print("_");
                else
                System.out.print("*");
            }
            System.out.println();
        }
    }
}