import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int[]arr={1,2,3,4,5,6,7};
        int rot=sc.nextInt();
        while (rot-->0)
        {
            int ele=arr[arr.length-1];
            for(int i=arr.length-1;i>0;i--)
                arr[i]=arr[i-1];
            arr[0]=ele;
        }
        //
        for(int i:arr)
            System.out.print(i+" ");
    }
}