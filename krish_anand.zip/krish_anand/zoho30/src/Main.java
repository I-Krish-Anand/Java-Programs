import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt(),b=sc.nextInt(),c=sc.nextInt();
        if(a>=b)
        {
            if(a>=c)
                System.out.println("Variable a is the largest with the value:"+a);
            else
                System.out.println("Variable c is the largest with the value:"+c);
        }
        else
        {
            if(b>=c)
                System.out.println("Variable b is the largest with the value:"+b);
            else
                System.out.println("Variable c is the largest with the value:"+c);
        }
    }
}