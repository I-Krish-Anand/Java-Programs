public class Main {
    static void mergesort(char[]a,int i,int j)
    {
        if(i<j) {
            int mid = (i + j) / 2;
            mergesort(a, i, mid);
            mergesort(a, mid+1, j);
            merge(a,i,mid,j);
        }
    }
    static void merge(char[]a,int i,int mid,int j)
    {
        int n1=mid-i+1;
        int n2=j-mid;
        char[]temp1=new char[n1];
        char[]temp2=new char[n2];

                for(int m=0;m<n1;m++)
                    temp1[m]=a[i+m];

                for (int m=0;m<n2;m++ )
                    temp2[m]=a[mid+1+m];

        int m=0,n=0;
        int k=i;

        while(m<n1 && n<n2)
        {
            if (temp1[m] >= temp2[n])
                a[k++]=temp1[m++];
            else
                a[k++]=temp2[n++];

        }
        while (m<n1)
            a[k++]=temp1[m++];
        while (n<n2)
            a[k++]=temp2[n++];

    }
    public static void main(String[] args) {
        String a="welcomeyoualltozohogradstudies";
        char[] arr=a.toCharArray();
        mergesort(arr, 0,a.length() - 1);
        System.out.print(new String(arr));
    }
}