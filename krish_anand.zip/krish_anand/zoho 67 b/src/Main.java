public class Main {
    public static void main(String[] args) {
        int[]arr={1,2,15,5,6,8,3,1,5,7,3,6,2,1};
        int max=Integer.MIN_VALUE;
        for(int i:arr)
        {
            if(i>max)
                max=i;
        }
        int[] freq=new int[max+1];
        for(int i:arr)
         freq[i]++;

        System.out.println("Duplicate Entries are:");
        for(int i=0;i<=max;i++)
        {
            if(freq[i]>1)
                System.out.print(i+" ");
        }

    }
}