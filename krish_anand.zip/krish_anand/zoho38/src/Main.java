import java.util.*;
public class Main {
    public static void main(String[] args) {
        int[]arr={143,56,74,35,24,674,355,77};
        int max=Integer.MIN_VALUE;
        for(int i:arr)
        {
            if(i>max)
                max=i;
        }
        System.out.print("Greatest Value in the array is:"+max);
    }
}