public class Main {
    public static void main(String[] args) {
        int[]arr={1,1,1,2,5,7,7,3,3,5,7,9,2,2};
        //using count sort algorithm
        int max=Integer.MIN_VALUE;
        for(int i:arr)
        {
            if(max<i)
                max=i;
        }
        int[]freq=new int[max+1];
        for(int i:arr)
            freq[i]++;
        //print
        for(int i=0;i<=max;i++)
        {
            if(freq[i]>0)
            {
                System.out.println(i+" Frequency :"+freq[i]);
            }
        }
    }
}