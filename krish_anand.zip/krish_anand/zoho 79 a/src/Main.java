import java.util.*;
public class Main {

    static boolean isIdentityMatrix(int[][]a)
    {
        for(int i=0;i< a.length;i++)
        {
            for(int j=0;j<a[0].length;j++)
            {
                if(!((i==j && a[i][j]==1) || a[i][j]==0))
                 return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Row size");
        int m= sc.nextInt();
        System.out.println("Column size:");
        int n=sc.nextInt();
        if(m==n) {
            int[][] a = new int[m][n];
            System.out.println("Matrix elements");
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    a[i][j] = sc.nextInt();
            System.out.println("Is Identity Matrix:?" + isIdentityMatrix(a));
        }
        else System.out.println("Not a Identity Matrix");
    }
}