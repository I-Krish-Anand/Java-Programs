import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        char[] ch={'w','e','l','c','o','m','e'};
        String a="";
        for (char k:ch)
         a+=String.valueOf(k);
        System.out.print(a);

    }
}