public class Main {
    public static void main(String[] args) {
        int[]arr={143,56,74,35,24,674,355,77};
        int []brr=new int[arr.length];
        System.arraycopy(arr,0,brr,0,brr.length);
        System.out.print("Array 1 elements:");
        for(int i:arr)
            System.out.print(i+" ");
        System.out.println("\n");
        System.out.print("Array 2 elements:");
        for(int i:brr)
            System.out.print(i+" ");
    }
}