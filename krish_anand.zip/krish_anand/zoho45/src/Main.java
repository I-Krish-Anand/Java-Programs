public class Main {
    public static void main(String[] args) {
        int[]arr={1,1,5,6,7,6,3,4,5,6,2,4,7,4,3};
        int sum=0;
        for(int i:arr)
        {
            sum+=i;
        }
        System.out.println("Sum of Elements is:"+sum);
    }
}