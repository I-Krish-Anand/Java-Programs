public class Main {

    static void swap(char[] arr,int i,int j)
    {
        char temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }

    static void stringSort(char[] arr)
    {
        int n=arr.length;
        for(int i=0;i<n;i++)
        {
            int max=i;
            for(int j=i+1;j<n;j++)
            {
                if(arr[j]>arr[max])
                    max=j;
            }
            swap(arr,i,max);
        }
    }
    public static void main(String[] args)
    {
        //  bubble sort
        String a="welcomeyoualltozohogradstudies";
        char[]arr=a.toCharArray();
        stringSort(arr);
        System.out.println(new String(arr));
    }
}