import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String a=sc.nextLine();
        StringTokenizer st=new StringTokenizer(a);
        String []arr=new String[st.countTokens()];
        int k=0;
        while (st.hasMoreTokens())
            arr[k++]=st.nextToken();
        for (String i:arr)
            System.out.print(i+" ");

    }
}