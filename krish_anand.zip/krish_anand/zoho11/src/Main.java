class Main
{
    static void print(int[][]a)
    {
        for(int i=0;i<a.length;i++)
        {
            for(int j=0;j< a[0].length;j++)
                System.out.print(a[i][j]+" ");
            System.out.println();
        }
    }

    //matrix leftshifting
    static void leftShift(int[][]a)
    {
        int row=a.length;
        int col=a[0].length;
        int m=0,n=0;
        while(m< row &&n <col)
        {
            int i=m;
            int ele=a[m][n];
            for(int j=n;j<col-1;j++)
                a[i][j]=a[i][j+1];
            int j=col-1;
            for( i=m;i<row-1;i++)
                a[i][j]=a[i+1][j];
            i=row-1;
            for(j=col-1;j>n;j--)
                a[i][j]=a[i][j-1];
            j=n;
            for(i=row-1;i>m+1;i--)
                a[i][j]=a[i-1][j];

            a[i][j]=ele;
            m++;
            n++;
            row--;
            col--;
        }
    }
    public static void main(String[] args)
    {
        int[][] a =   {{1, 2, 3,4},
                      {5,6,7,8},
                      {9,10,11,12},
                      {13,14,15,16}};
        leftShift(a);
        print(a);

    }
}