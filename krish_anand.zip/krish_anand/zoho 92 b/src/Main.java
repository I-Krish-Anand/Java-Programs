import java.util.Arrays;
public class Main {

    static int swap(String[]arr,int j,int i)
    {
        if(arr[j].compareTo(arr[i])>0) {
            String tem = arr[j];
            arr[j] = arr[i];
            arr[i] = tem;
        }
        return  i+1;
    }
    static int stringSort(String[] arr,int i,int j) {

        if ( i-1==j)
            return i;
        return swap(arr, j,stringSort(arr,i-1,j));

    }
    static void outerLoop(String[]arr,int i)
    {
        if(i==0)
            return;
        stringSort(arr,arr.length, arr.length-i);
        outerLoop(arr,i-1);
    }
    public static void main(String[] args)
    {
        //using backward recursive selection sort algorithm
        String a= "apple banana carrot drums tortoise elephant";
        String[]arr=a.split(" ");
        outerLoop(arr, arr.length);
        System.out.println(Arrays.toString(arr));
    }
}