import java.util.Arrays;

public class Main {
    static String stringSort(String[] arr,int i) {
        if (i == 0)
            return arr[i];

        if (arr[i].compareTo(stringSort(arr, i - 1)) < 0)
        {
            String temp=arr[i];
            arr[i]=arr[i-1];
            arr[i-1]=temp;
        }
        return arr[i];

    }
    static void outerLoop(String[]arr,int i)
    {
        if(i==0)
            return;
        stringSort(arr,i);
        outerLoop(arr,i-1);
    }
    public static void main(String[] args)
    {
        // recursive bubble sort using reverse order
        String a="welcome you all to zoho grad studies";
        String[]arr=a.split(" ");
        outerLoop(arr, arr.length - 1);
        System.out.println(Arrays.toString(arr));
    }
}