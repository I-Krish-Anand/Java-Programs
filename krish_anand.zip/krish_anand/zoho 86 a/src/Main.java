
public class Main {
    static void arrayPrint(char[]arr,int i)
    {
        if(i==arr.length)
            return;

        System.out.print(arr[i]+" ");
        arrayPrint(arr,i+1);
    }
    public static void main(String[] args)
    {
        char[] ch={'w','e','l','c','o','m','e'};
        arrayPrint(ch,0);

    }
}