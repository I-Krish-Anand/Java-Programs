public class Main {
    static void print(int[]arr,int i)
    {
        if(i>=arr.length)
         return;

        System.out.print(arr[i]+" ");
        print(arr,i+2);
    }
    public static void main(String[] args)
    {
        int[]arr={1,2,3,4,5,6,7,8,9,10};
        //to print elements at odd position
        print(arr,0);

        System.out.println();
        
        //to print elements at even position
        print(arr,1);
    }
}