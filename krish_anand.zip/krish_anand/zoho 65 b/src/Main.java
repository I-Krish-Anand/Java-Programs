import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        int[]arr={1,1,1,2,5,7,7,3,3,5,7,9,2,2,15};
        Arrays.sort(arr);
        int count=1, i;
        for( i=0;i<arr.length-1;i++)
        {
            if(arr[i]!=arr[i+1])
            {
                System.out.println(arr[i]+" Frequency:"+count);
                count=1;
            }
            else
            count++;
        }
            System.out.println(arr[i]+" Frequency:"+count);
    }
}