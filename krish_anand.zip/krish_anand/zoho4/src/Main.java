public class Main {

    public static void main(String[] args) {
        for(int i=0;i<=1;i++)
        {
            for(int j=0;j<=1;j++)
            {
                System.out.println("Bitwise AND of:"+i+" "+j+" "+(i&j));
                System.out.println("Bitwise exclusive OR of:"+i+" "+j+" "+(i^j));
                System.out.println("Bitwise inclusive OR of:"+i+" "+j+" "+(i|j));
                System.out.println("Bitwise Left Shift of:"+i+" "+j+" "+(i<<j));
                System.out.println("Bitwise Right Shift of:"+i+" "+j+" "+(i>>j));
                System.out.println("Unsigned Right Shift of:"+i+" "+j+" "+(i>>>j));
                System.out.println("Bitwise Complement of:"+i+" "+j+" "+(~j));
                System.out.println("\n");

            }
        }

    }
}