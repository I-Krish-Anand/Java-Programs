import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int students=sc.nextInt();
        int count= sc.nextInt();
        int count1=count;
            for(int i=101;count1-->0;i++)
            {
                for(int temp=i;temp<=(100+students);temp+=count)
                    System.out.println(temp);

                System.out.println();
            }

    }
}